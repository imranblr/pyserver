user# Exercise Overview

In this exercise, you will be creating a small Python server that interacts with a PostgreSQL database. The entire service is containerized using Docker and involves multiple tasks outlined below.

## Instructions

**Time Allocation**: Please limit your time investment to a maximum of 1 hour for this exercise.

**Objective**: The primary aim of this exercise is to prompt the creation of a Python server interacting with a PostgreSQL DB, encapsulated within a Docker container. Your approach to problem-solving, decision-making, and adaptability is of greater importance than achieving perfection in task completion. You are also asked to update the `Checklist.md` file based on the tasks you completed.

**Expectations**

1. **Thoughtful Problem Solving**: Prioritize a transparent thought process over mere task completion. We value understanding your approach more than expecting flawless solutions.
  
2. **Innovative Problem-solving**: If you uncover enhancements beyond the specified tasks, don't hesitate to implement them. We're eager to witness your innovative choices and comprehend the reasoning behind them.

3. **Discussion Readiness**: Prepare for a thorough discussion on:
   - **Your Process**: Detail how you initiated the exercise, navigated challenges, and utilized any research or external resources.
   - **Decision Rationale**: Articulate the reasons guiding the choices made during the exercise.
   - **Alternative Approaches**: Explore how you might tackle the tasks differently and consider potential avenues for improvement.

4. **Git Best Practices**:
   - Commit frequently and succinctly, ensuring each commit represents a logical unit of change.
   - Craft meaningful commit messages that provide clear insights into the changes.
   - Leverage tags for versioning and releases to streamline project management.
   - Employ branches wisely to organize development efforts effectively.

**Discussion Focus**

During our meeting, we will focus on:

* Understanding your problem-solving approach.
* Exploring the reasoning behind your decisions.
* Discussing potential alternative strategies.
* Assessing your adaptability and analytical mindset.

## Task List

## Task 1: Initial Setup (Expected time: 10 mins)

1.1 Create a private empty repository on Github or Gitlab

1.2 Push the included code to the repository

1.3 Add proper `.gitignore` file in the repository.

1.4 Write a Dockerfile for the Python application.

   - Set Python version to 3.7.
   - Set environment variable `MODE` based on the build argument.
   - Install PostgreSQL version 12 (`psql`).
   - Populate `requirements.txt` with specified libraries.
   - Install dependencies using `pip`.
   - Container should run `sleep infinity` by default.
   - Preserve `COPY . /app` line in the Dockerfile.

## Task 2: Docker Compose Configuration (Expected time: 15 mins)

2.1 Write a docker-compose file.

   - Start the above Docker image.
   - Build if not present, set `mode=dev`.
   - Use a volume for instant local changes reflection.
   - Run `uvicorn main:app --reload` at startup.
   - Set environment variable `LOG_LEVEL` to `debug`.
   - Allow shelling into the container using `docker exec -it server /bin/bash`.
   - Start PostgreSQL version 12 with a database named `demo`, user `demouser`, and password `password`.

## Task 3: Database Initialization Script (Expected time: 5 mins)

3.1 Create `create-db-and-tables.sh` script.

   - Make it executable.
   - Read environment variables for PostgreSQL credentials.
   - Use `psql` to create a table named `store` with an auto-incremented `id` column and a text column `name`.
   - Execute the script on the server container to populate the database.

## Task 4: Application Configuration (Expected time: 20 mins)

4.1 Open `main.py` file.

   - Print `MODE` on startup if `LOG_LEVEL` is set to `debug`.
   - Create a FastAPI route that adds a store to the database based on the provided `store_name`.
   - **Bonus**: Write unit tests for automatic execution during image build.

## Task 5: cURL Command (Expected time: 5 mins)

5.1 Provide a cURL command to post data to the Python service.

   - The command should insert a store with the name `test_store` into the database.

## (Bonus) Task 6: CI/CD Setup (Expected time: 10 mins)

6.1 Setup GitHub Actions or CircleCI.

   - Verify all tasks within the actions, including proper testing.
   - Ensure that the build fails if any tests fail.
