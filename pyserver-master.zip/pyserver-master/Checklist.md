- [Done] Task 1
- [DONE] Task 2
- [ ] Task 3
- [ ] Task 4
- [ ] Task 5
- [ ] Task 6


Resources used:

1. www.icrc.org -> To understand what is ICRC
