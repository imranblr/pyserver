#!/bin/sh
su postgres -c 'pg_ctl start -D /var/lib/postgresql/data'
su postgres -c 'psql --command \"ALTER USER demo WITH ENCRYPTED PASSWORD 'demo';\""
su postgres -c '"psql --command \"CREATE DATABASE store;\""